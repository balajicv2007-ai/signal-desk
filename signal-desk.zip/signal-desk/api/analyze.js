// Vercel serverless function.
// Runs on the server, so the API key never reaches the browser.
export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { text } = req.body || {};
  if (!text || typeof text !== "string") {
    return res.status(400).json({ error: "Missing 'text' in request body" });
  }

  const systemPrompt = `You are a fake-news / misinformation triage assistant for a hackathon demo. Analyze the headline or article text a user submits.

Respond with ONLY valid JSON, no markdown fences, no preamble, matching exactly this shape:
{
  "verdict": "real" | "fake" | "uncertain",
  "confidence": <integer 0-100>,
  "summary": "<1-2 sentence plain-language summary of your assessment>",
  "signals": [
    {"label": "<short signal name, 2-4 words>", "detected": <true|false>, "note": "<one short sentence explaining this specific signal for this text>"}
  ]
}

Include exactly 5 signals, chosen from things like: sensational or emotionally charged language, unverifiable or absent sources, extraordinary claims without evidence, clickbait framing, internal inconsistency, presence of specific verifiable facts (named sources, dates, figures), neutral/measured tone, alignment with known reliable reporting patterns. "detected": true means the signal is a red flag present in the text; false means that concern is NOT present (i.e. text passes on that signal). Keep notes concrete and specific to the submitted text, not generic.`;

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 1000,
        system: systemPrompt,
        messages: [{ role: "user", content: text.slice(0, 4000) }],
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      return res.status(502).json({ error: "Upstream API error", detail: errText });
    }

    const data = await response.json();
    const raw = (data.content || [])
      .map((b) => (b.type === "text" ? b.text : ""))
      .join("")
      .trim();
    const clean = raw.replace(/^```json\s*|```$/g, "").trim();
    const parsed = JSON.parse(clean);

    return res.status(200).json(parsed);
  } catch (err) {
    return res.status(500).json({ error: "Server error", detail: String(err) });
  }
}
