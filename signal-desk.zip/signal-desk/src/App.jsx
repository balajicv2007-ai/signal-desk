import React, { useState, useEffect, useRef } from "react";

const SAMPLES = [
  {
    label: "Sample: sensational",
    text: "SHOCKING: Scientists Confirm Drinking Bleach Cures All Diseases, Government Hiding Truth From Public!!!",
  },
  {
    label: "Sample: measured",
    text: "The Reserve Bank of India kept its repo rate unchanged at 6.5% on Wednesday, citing steady inflation and the need to support economic growth, according to the RBI's monetary policy statement.",
  },
  {
    label: "Sample: ambiguous",
    text: "Local farmers claim a new fertilizer blend doubled their crop yield this season, though agricultural officials say they have not yet reviewed the data.",
  },
];

const FONT_LINK =
  "https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@600;700;900&family=PT+Serif:ital,wght@0,400;0,700;1,400&family=IBM+Plex+Mono:wght@400;500;600&display=swap";

function useFonts() {
  useEffect(() => {
    if (document.getElementById("wire-fonts")) return;
    const link = document.createElement("link");
    link.id = "wire-fonts";
    link.rel = "stylesheet";
    link.href = FONT_LINK;
    document.head.appendChild(link);
  }, []);
}

function todayDateline() {
  const d = new Date();
  return d
    .toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })
    .toUpperCase();
}

const VERDICT_STYLES = {
  real: {
    label: "VERIFIED",
    color: "#4C7A63",
    rotate: "-6deg",
  },
  fake: {
    label: "FLAGGED",
    color: "#C1443C",
    rotate: "-4deg",
  },
  uncertain: {
    label: "UNVERIFIED",
    color: "#C99A44",
    rotate: "-7deg",
  },
};

function StampMark({ verdict }) {
  const s = VERDICT_STYLES[verdict] || VERDICT_STYLES.uncertain;
  return (
    <div
      style={{
        display: "inline-block",
        border: `4px solid ${s.color}`,
        color: s.color,
        padding: "10px 22px",
        transform: `rotate(${s.rotate})`,
        fontFamily: "'Barlow Condensed', sans-serif",
        fontWeight: 900,
        fontSize: "clamp(28px, 5vw, 44px)",
        letterSpacing: "4px",
        borderRadius: "3px",
        opacity: 0.95,
        userSelect: "none",
      }}
      aria-label={`Verdict: ${s.label}`}
    >
      {s.label}
    </div>
  );
}

function SignalRow({ signal }) {
  const on = signal.detected;
  return (
    <div
      style={{
        display: "flex",
        alignItems: "flex-start",
        gap: 12,
        padding: "10px 0",
        borderBottom: "1px solid rgba(20,23,28,0.12)",
      }}
    >
      <div
        style={{
          flexShrink: 0,
          width: 10,
          height: 10,
          marginTop: 6,
          borderRadius: "50%",
          background: on ? "#C1443C" : "#4C7A63",
        }}
      />
      <div style={{ flex: 1 }}>
        <div
          style={{
            fontFamily: "'IBM Plex Mono', monospace",
            fontSize: 12,
            letterSpacing: "0.5px",
            color: "#14171C",
            fontWeight: 600,
            textTransform: "uppercase",
          }}
        >
          {signal.label}
        </div>
        <div
          style={{
            fontFamily: "'PT Serif', serif",
            fontSize: 14,
            color: "#4a4a44",
            marginTop: 2,
          }}
        >
          {signal.note}
        </div>
      </div>
    </div>
  );
}

export default function FakeNewsDesk() {
  useFonts();
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [result, setResult] = useState(null);
  const [dateline] = useState(todayDateline());
  const resultRef = useRef(null);

  async function analyze() {
    if (!text.trim() || loading) return;
    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: text.slice(0, 4000) }),
      });
      if (!response.ok) {
        throw new Error("Request failed");
      }
      const parsed = await response.json();
      setResult(parsed);
      setTimeout(() => {
        resultRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
      }, 80);
    } catch (e) {
      setError("The wire dropped the signal. Try again in a moment.");
    } finally {
      setLoading(false);
    }
  }

  const charCount = text.length;

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#14171C",
        color: "#EDEAE1",
        fontFamily: "'PT Serif', serif",
        paddingBottom: 60,
      }}
    >
      {/* Masthead */}
      <header
        style={{
          borderBottom: "3px solid #EDEAE1",
          padding: "28px 20px 16px",
          maxWidth: 860,
          margin: "0 auto",
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "baseline",
            fontFamily: "'IBM Plex Mono', monospace",
            fontSize: 11,
            letterSpacing: "1.5px",
            color: "#8B8B85",
            marginBottom: 6,
          }}
        >
          <span>{dateline}</span>
          <span>WIRE No. 32 — MISINFORMATION DESK</span>
        </div>
        <h1
          style={{
            fontFamily: "'Barlow Condensed', sans-serif",
            fontWeight: 900,
            fontSize: "clamp(40px, 8vw, 68px)",
            letterSpacing: "1px",
            margin: 0,
            lineHeight: 0.95,
          }}
        >
          THE SIGNAL DESK
        </h1>
        <p
          style={{
            fontFamily: "'PT Serif', serif",
            fontStyle: "italic",
            color: "#c7c4b9",
            fontSize: 16,
            marginTop: 8,
          }}
        >
          Paste a headline or article. We break down the tell-tale signals of
          misinformation before you share it.
        </p>
      </header>

      {/* Hero / input */}
      <main style={{ maxWidth: 860, margin: "0 auto", padding: "0 20px" }}>
        <section style={{ marginTop: 28 }}>
          <div
            style={{
              background: "#EDEAE1",
              color: "#14171C",
              borderRadius: 4,
              padding: 22,
              boxShadow: "0 10px 30px rgba(0,0,0,0.35)",
            }}
          >
            <label
              htmlFor="article-input"
              style={{
                display: "block",
                fontFamily: "'IBM Plex Mono', monospace",
                fontSize: 11,
                letterSpacing: "1.5px",
                color: "#4a4a44",
                marginBottom: 8,
                textTransform: "uppercase",
              }}
            >
              Submit copy for analysis
            </label>
            <textarea
              id="article-input"
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Paste a headline, tweet, or article paragraph here..."
              rows={6}
              style={{
                width: "100%",
                resize: "vertical",
                border: "1.5px solid #14171C",
                borderRadius: 3,
                padding: 14,
                fontFamily: "'PT Serif', serif",
                fontSize: 16,
                background: "#fffdf8",
                color: "#14171C",
                boxSizing: "border-box",
                outline: "none",
              }}
            />
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                marginTop: 12,
                flexWrap: "wrap",
                gap: 10,
              }}
            >
              <span
                style={{
                  fontFamily: "'IBM Plex Mono', monospace",
                  fontSize: 11,
                  color: "#8B8B85",
                }}
              >
                {charCount} / 4000 characters
              </span>
              <button
                onClick={analyze}
                disabled={!text.trim() || loading}
                style={{
                  fontFamily: "'Barlow Condensed', sans-serif",
                  fontWeight: 700,
                  fontSize: 18,
                  letterSpacing: "2px",
                  padding: "10px 26px",
                  background: !text.trim() || loading ? "#a9a89e" : "#14171C",
                  color: "#EDEAE1",
                  border: "none",
                  borderRadius: 3,
                  cursor: !text.trim() || loading ? "default" : "pointer",
                  transition: "background 0.15s ease",
                }}
              >
                {loading ? "TRANSMITTING…" : "RUN ANALYSIS"}
              </button>
            </div>

            <div
              style={{
                marginTop: 16,
                display: "flex",
                gap: 8,
                flexWrap: "wrap",
              }}
            >
              {SAMPLES.map((s) => (
                <button
                  key={s.label}
                  onClick={() => setText(s.text)}
                  style={{
                    fontFamily: "'IBM Plex Mono', monospace",
                    fontSize: 11,
                    letterSpacing: "0.5px",
                    padding: "6px 10px",
                    background: "transparent",
                    border: "1px solid #14171C",
                    borderRadius: 3,
                    color: "#14171C",
                    cursor: "pointer",
                  }}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>
        </section>

        {error && (
          <div
            style={{
              marginTop: 20,
              color: "#C1443C",
              fontFamily: "'IBM Plex Mono', monospace",
              fontSize: 13,
            }}
          >
            {error}
          </div>
        )}

        {/* Results */}
        {result && (
          <section
            ref={resultRef}
            style={{
              marginTop: 34,
              background: "#EDEAE1",
              color: "#14171C",
              borderRadius: 4,
              padding: 26,
              boxShadow: "0 10px 30px rgba(0,0,0,0.35)",
            }}
          >
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "flex-start",
                flexWrap: "wrap",
                gap: 16,
                marginBottom: 18,
              }}
            >
              <StampMark verdict={result.verdict} />
              <div style={{ textAlign: "right" }}>
                <div
                  style={{
                    fontFamily: "'IBM Plex Mono', monospace",
                    fontSize: 11,
                    color: "#8B8B85",
                    letterSpacing: "1px",
                  }}
                >
                  CONFIDENCE
                </div>
                <div
                  style={{
                    fontFamily: "'IBM Plex Mono', monospace",
                    fontSize: 34,
                    fontWeight: 600,
                    lineHeight: 1,
                  }}
                >
                  {result.confidence}%
                </div>
              </div>
            </div>

            <p
              style={{
                fontFamily: "'PT Serif', serif",
                fontSize: 17,
                lineHeight: 1.5,
                marginBottom: 18,
              }}
            >
              {result.summary}
            </p>

            <div
              style={{
                fontFamily: "'IBM Plex Mono', monospace",
                fontSize: 11,
                letterSpacing: "1.5px",
                color: "#8B8B85",
                marginBottom: 4,
                textTransform: "uppercase",
              }}
            >
              Signal breakdown
            </div>
            <div>
              {(result.signals || []).map((s, i) => (
                <SignalRow key={i} signal={s} />
              ))}
            </div>
          </section>
        )}
      </main>

      {/* Footer */}
      <footer
        style={{
          maxWidth: 860,
          margin: "50px auto 0",
          padding: "18px 20px 0",
          borderTop: "1px solid #33363c",
        }}
      >
        <div
          style={{
            fontFamily: "'IBM Plex Mono', monospace",
            fontSize: 11,
            color: "#8B8B85",
            letterSpacing: "0.5px",
            lineHeight: 1.8,
          }}
        >
          DEMO NOTE — this build runs live language-model reasoning in place of
          a trained BERT/transformer classifier, so the same problem
          statement (source credibility, semantic inconsistency, evolving
          deceptive language) is demonstrated end-to-end without a training
          pipeline. Swap in a fine-tuned classifier + web-scraped corpus for
          the production version.
        </div>
        <div
          style={{
            display: "flex",
            gap: 8,
            flexWrap: "wrap",
            marginTop: 14,
          }}
        >
          {["Python", "NLP", "BERT / Transformer", "Web scraping"].map(
            (t) => (
              <span
                key={t}
                style={{
                  fontFamily: "'IBM Plex Mono', monospace",
                  fontSize: 10,
                  letterSpacing: "0.5px",
                  padding: "5px 9px",
                  border: "1px solid #33363c",
                  borderRadius: 3,
                  color: "#8B8B85",
                }}
              >
                {t}
              </span>
            )
          )}
        </div>
      </footer>
    </div>
  );
}
